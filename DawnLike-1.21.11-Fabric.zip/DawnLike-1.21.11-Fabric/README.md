# DawnLike 1.21.11 Fabric

Starter client-side Fabric mod.

- Minecraft 1.21.11
- Fabric
- Java 21
- Right Shift opens the Click GUI
- Toggleable starter modules
- Dawn-like dark UI

Build with `./gradlew build` after installing the Gradle wrapper or using a compatible Gradle installation.
