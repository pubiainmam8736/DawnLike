package com.example.dawnlike;

import com.example.dawnlike.gui.ClickGuiScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

public class DawnLikeClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ModuleManager.init();

        KeyMapping guiKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.dawnlike.click_gui",
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.dawnlike"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (guiKey.consumeClick()) {
                client.setScreen(new ClickGuiScreen());
            }
        });
    }
}
