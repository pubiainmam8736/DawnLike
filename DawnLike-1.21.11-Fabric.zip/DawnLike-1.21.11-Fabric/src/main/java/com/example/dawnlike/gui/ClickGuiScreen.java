package com.example.dawnlike.gui;

import com.example.dawnlike.Module;
import com.example.dawnlike.ModuleManager;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import java.util.List;

public class ClickGuiScreen extends Screen {
    private Module.Category category = Module.Category.RENDER;

    public ClickGuiScreen() {
        super(Component.literal("DawnLike"));
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        int w = 780, h = 470;
        int x = (width - w) / 2, y = (height - h) / 2;

        g.fill(0, 0, width, height, 0x99000000);
        g.fill(x, y, x + w, y + h, 0xFF111318);
        g.fill(x, y, x + 190, y + h, 0xFF0D0F13);
        g.fill(x + 190, y, x + w, y + 58, 0xFF151820);

        g.drawString(font, "DAWNLIKE", x + 24, y + 22, 0xFFFFFFFF);
        g.drawString(font, "Client", x + 24, y + 39, 0xFF777D89);

        Module.Category[] cats = Module.Category.values();
        for (int i = 0; i < cats.length; i++) {
            int cy = y + 85 + i * 48;
            boolean selected = cats[i] == category;
            if (selected) g.fill(x + 12, cy - 8, x + 178, cy + 28, 0xFF2B65D9);
            g.drawString(font, cats[i].name(), x + 28, cy + 5,
                    selected ? 0xFFFFFFFF : 0xFF9AA0AA);
        }

        g.drawString(font, category.name(), x + 220, y + 22, 0xFFFFFFFF);
        g.drawString(font, "Right Shift to toggle GUI", x + 220, y + 39, 0xFF777D89);

        List<Module> list = ModuleManager.all().stream()
                .filter(m -> m.category() == category).toList();

        int cardX = x + 220, cardY = y + 82;
        for (int i = 0; i < list.size(); i++) {
            Module m = list.get(i);
            int row = i / 2, col = i % 2;
            int bx = cardX + col * 260, by = cardY + row * 82;
            g.fill(bx, by, bx + 240, by + 66, 0xFF1B1F27);
            g.drawString(font, m.name(), bx + 16, by + 15, 0xFFFFFFFF);
            g.drawString(font, m.enabled() ? "ON" : "OFF", bx + 16, by + 38,
                    m.enabled() ? 0xFF5EDB91 : 0xFF777D89);
            int sx = bx + 192, sy = by + 24;
            g.fill(sx, sy, sx + 32, sy + 16,
                    m.enabled() ? 0xFF2B65D9 : 0xFF454A54);
            g.fill(sx + (m.enabled() ? 18 : 2), sy + 2,
                    sx + (m.enabled() ? 30 : 14), sy + 14, 0xFFFFFFFF);
        }

        super.render(g, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);

        int w = 780, h = 470;
        int x = (width - w) / 2, y = (height - h) / 2;

        for (int i = 0; i < Module.Category.values().length; i++) {
            int cy = y + 85 + i * 48;
            if (mouseX >= x + 12 && mouseX <= x + 178 &&
                mouseY >= cy - 8 && mouseY <= cy + 28) {
                category = Module.Category.values()[i];
                return true;
            }
        }

        List<Module> list = ModuleManager.all().stream()
                .filter(m -> m.category() == category).toList();

        int cardX = x + 220, cardY = y + 82;
        for (int i = 0; i < list.size(); i++) {
            int row = i / 2, col = i % 2;
            int bx = cardX + col * 260, by = cardY + row * 82;
            if (mouseX >= bx && mouseX <= bx + 240 &&
                mouseY >= by && mouseY <= by + 66) {
                list.get(i).toggle();
                return true;
            }
        }
        return true;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
