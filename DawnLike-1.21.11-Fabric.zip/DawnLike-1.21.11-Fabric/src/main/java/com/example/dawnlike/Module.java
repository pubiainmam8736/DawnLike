package com.example.dawnlike;

public class Module {
    public enum Category { COMBAT, MOVEMENT, RENDER, PLAYER, MISC }

    private final String name;
    private final Category category;
    private boolean enabled;

    public Module(String name, Category category) {
        this.name = name;
        this.category = category;
    }

    public String name() { return name; }
    public Category category() { return category; }
    public boolean enabled() { return enabled; }
    public void toggle() { enabled = !enabled; }
}
