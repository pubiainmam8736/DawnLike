package com.example.dawnlike;

import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();

    public static void init() {
        if (!MODULES.isEmpty()) return;
        MODULES.add(new Module("Sprint", Module.Category.MOVEMENT));
        MODULES.add(new Module("Fullbright", Module.Category.RENDER));
        MODULES.add(new Module("Keystrokes", Module.Category.RENDER));
        MODULES.add(new Module("FPS", Module.Category.RENDER));
        MODULES.add(new Module("Coordinates", Module.Category.RENDER));
        MODULES.add(new Module("NoFall", Module.Category.PLAYER));
        MODULES.add(new Module("AutoGG", Module.Category.MISC));
        MODULES.add(new Module("Reach Display", Module.Category.COMBAT));
    }

    public static List<Module> all() {
        return MODULES;
    }
}
